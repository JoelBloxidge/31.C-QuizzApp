package com.example.a31c_quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, QuizActivity1.class); //Intent to move to next activity
        EditText texteditName = (EditText) findViewById(R.id.texteditName);
        Button buttonName = (Button) findViewById(R.id.buttonName);

        buttonName.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                name = texteditName.getText().toString();
                startActivity(intent);
            }
        });

    }

    protected void onResume() {
        // Activity Result Intent Initialization
        //Dr Azadeh Ghari Neiat, SIT305 Week 3 Practical Expense Manager App, Referenced 19 April 2021, Deakin University
        super.onResume();
        Intent intentReturn = new Intent();
        intentReturn.putExtra("name", name);
        setResult(RESULT_OK, intentReturn);
        finish();
    }
}