package com.example.a31c_quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class end extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);
    }
}