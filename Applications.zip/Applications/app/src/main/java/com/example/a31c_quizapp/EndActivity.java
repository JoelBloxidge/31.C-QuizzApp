package com.example.a31c_quizapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class EndActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end2);

        TextView textScore = findViewById(R.id.textScore);
        TextView textName = findViewById(R.id.texteditName);

        Intent nameIntent = new Intent(getApplicationContext(), MainActivity.class); //intent for name retrieval
        nameIntent.putExtra("name", textName.getText().toString());
        startActivityForResult(nameIntent, 1);

        Intent intent = getIntent();
        String score = intent.getStringExtra("score"); //getting string for score from previous

        textScore.setText("you receieved " + score + "/5");

        Button buttonNew = findViewById(R.id.buttonNewQuiz);
        Intent quizIntent = new Intent(this, MainActivity.class);
        Button buttonNext = findViewById(R.id.buttonFinish);

        buttonNew.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                startActivity(quizIntent);
            }
        });

        buttonNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { //Dr Azadeh Ghari Neiat, SIT305 Week 3 Practical Expense Manager App, Referenced 19 April 2021, Deakin University
        super.onActivityResult(requestCode, resultCode, data);
        TextView textCongratulations = findViewById(R.id.textCongratulations);
        if (resultCode == RESULT_OK)
        {
            if (resultCode ==1)
            {
                String name = data.getStringExtra("name");
                textCongratulations.setText("Congratulations " + name);
            }
        }
    }
}