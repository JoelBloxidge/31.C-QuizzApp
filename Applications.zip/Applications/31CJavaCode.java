///Main Activity
package com.example.a31c_quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, QuizActivity1.class); //Intent to move to next activity
        EditText texteditName = (EditText) findViewById(R.id.texteditName);
        Button buttonName = (Button) findViewById(R.id.buttonName);

        buttonName.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                name = texteditName.getText().toString();
                startActivity(intent);
            }
        });

    }

    protected void onResume() {
        // Activity Result Intent Initialization
        //Dr Azadeh Ghari Neiat, SIT305 Week 3 Practical Expense Manager App, Referenced 19 April 2021, Deakin University
        super.onResume();
        Intent intentReturn = new Intent();
        intentReturn.putExtra("name", name);
        setResult(RESULT_OK, intentReturn);
        finish();
    }
}


/// QuizActivity

package com.example.a31c_quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

public class QuizActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz1);
        final int[] option = {0}; // Selection of answer option
        //Correct Answers
        final int[] answer = new int[] {
                1,
                0,
                0,
                2,
                1
        };
        //Strings for information
        final String[] questionDesc = new String[] {
                "1: What programming language do we use in SIT305",
                "2: What platform do we use",
                "3: What android resource do we use to edit text",
                "4: What is a toast",
                "5: What does a application comprise of"
        };
        final String[] answerOptions1 = new String[] {
                "1: Kotlin",
                "2: Android",
                "3: TextEdit",
                "4: Closes Application",
                "5: Jars"
        };
        final String[] answerOptions2 = new String[] {
                "1: Java",
                "2: IOS",
                "3: EditText",
                "4: Turns off Phone",
                "5: Android Activities"
        };
        final String[] answerOptions3 = new String[] {
                "1: C#",
                "2: Windows",
                "3: edit_text",
                "4: A Pop-up",
                "5: Paper"
        };
        final int[] x = {0}, p = {0}; //Int array for answers

        Intent intent = new Intent(this, EndActivity.class); //Intent for actiivty transition
        ListView listQuizView = (ListView) findViewById(R.id.listQuiz); // List view for selection of options
        TextView textQuestionDesc =  (TextView) findViewById(R.id.textQuestionDesc);
        Button buttonSubmit = (Button) findViewById(R.id.buttonSubmit); //Submission of answer
        Button buttonNext = (Button) findViewById(R.id.buttonNext); //Movement onto next answer or activity
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar); //Progress of quizz
        int progressStatus = 0;
        ArrayList<String> listQuiz = new ArrayList<String>();

        //Adding the first options
        listQuiz.add(answerOptions1[x[0]]);
        listQuiz.add(answerOptions2[x[0]]);
        listQuiz.add(answerOptions3[x[0]]);

        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.list_item, listQuiz);
        listQuizView.setAdapter(adapter);
        listQuizView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //TextView item = (TextView) view.findViewById(android.R.id.text1);
                //item.setBackgroundColor(android.R.color.holo_red_light);
                option[0] = position; //clicked option into variable
                buttonSubmit.setVisibility(View.VISIBLE); //allowing submission of answer
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                if (testResults(option[0], answer[x[0]]) == true) //if answer is correct change selected option to green
                {
                    listQuizView.getChildAt(answer[x[0]]).setBackgroundColor(android.R.color.holo_green_light);
                    p[0]++; //correct answer counter
                }
                else // wrong option
                {
                    listQuizView.getChildAt(option[0]).setBackgroundColor(android.R.color.holo_red_light);
                    listQuizView.getChildAt(answer[x[0]]).setBackgroundColor(android.R.color.holo_green_light);
                }
                buttonSubmit.setVisibility(View.INVISIBLE);
                buttonNext.setVisibility(View.VISIBLE); //button to move on is now visible
            }
        });

        // new options
        buttonNext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                x[0]++; // quiz counter
                progressBar.setProgress(progressStatus + 20); //progress bar
                if (x[0] == 4) {
                    intent.putExtra("score", String.valueOf(p[0])); //moving onto the final activity
                    startActivity(intent);
                }
                else {
                    // changing the options in the array
                    listQuiz.set(0, answerOptions1[x[0]]);
                    listQuiz.set(1, answerOptions2[x[0]]);
                    listQuiz.set(2, answerOptions3[x[0]]);

                    textQuestionDesc.setText(questionDesc[x[0]]); // new question description
                }
            }
        });



    }

    private boolean testResults(int position, int answer)
    {
        if (position == answer){
            return true;
        }
        else return false;
    }


}


///EndActivity

package com.example.a31c_quizapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class EndActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end2);

        TextView textScore = findViewById(R.id.textScore);
        TextView textName = findViewById(R.id.texteditName);

        Intent nameIntent = new Intent(getApplicationContext(), MainActivity.class); //intent for name retrieval
        nameIntent.putExtra("name", textName.getText().toString());
        startActivityForResult(nameIntent, 1);

        Intent intent = getIntent();
        String score = intent.getStringExtra("score"); //getting string for score from previous

        textScore.setText("you receieved " + score + "/5");

        Button buttonNew = findViewById(R.id.buttonNewQuiz);
        Intent quizIntent = new Intent(this, MainActivity.class);
        Button buttonNext = findViewById(R.id.buttonFinish);

        buttonNew.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                startActivity(quizIntent);
            }
        });

        buttonNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { //Dr Azadeh Ghari Neiat, SIT305 Week 3 Practical Expense Manager App, Referenced 19 April 2021, Deakin University
        super.onActivityResult(requestCode, resultCode, data);
        TextView textCongratulations = findViewById(R.id.textCongratulations);
        if (resultCode == RESULT_OK)
        {
            if (resultCode ==1)
            {
                String name = data.getStringExtra("name");
                textCongratulations.setText("Congratulations " + name);
            }
        }
    }
}